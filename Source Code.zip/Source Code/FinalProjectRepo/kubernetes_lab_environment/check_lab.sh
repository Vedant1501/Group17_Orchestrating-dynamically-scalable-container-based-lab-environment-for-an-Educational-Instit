# After running Start_Lab.sh, run this command to find the ip address of JupyterHub
kubectl get service --namespace jhub
